

---
压缩方式：
- 注 ：仅pngquant时，表示将忽略spine的png图集之压缩其他普通png图片；
-     仅tinypng时，表示将所有图片都用此方式压缩，包括spine图集以及png、jpg、jpeg格式图片；
-     pngquant和tinypng时，表示将spine图集用tinypng方式压缩，其他png(不包含jpg、jpeg)图片用pngquant方式压缩。